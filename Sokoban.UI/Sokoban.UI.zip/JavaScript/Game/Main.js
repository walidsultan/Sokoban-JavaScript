﻿$(document).ready(function () {
    FastClick.attach(document.body);
    InitializeView('app.ui.Menu');
});