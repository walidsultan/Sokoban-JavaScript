﻿var ObjectType = {
    floor: 'floor',
    box: 'box',
    player: 'player',
    target: 'target',
    wall: 'wall'
}

var Direction = {
    left: 'left',
    right: 'right',
    top: 'top',
    down: 'down'
}